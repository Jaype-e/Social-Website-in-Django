from django.contrib import admin
from .models import Question
from .models import News, Reserv,Post

admin.site.register(Question)
admin.site.register(News)
admin.site.register(Reserv)
admin.site.register(Post)
