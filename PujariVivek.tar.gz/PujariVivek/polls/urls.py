from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^(?P<page>[0-9]+)/$', views.home, name='home'),
    url(r'^register/$', views.register, name='register'),
    url(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
    url(r'^reservation/$', views.reservation, name='reservation'),
    url(r'^contact/(?P<name>[a-z]+)/$', views.contact, name='contact'),
    url(r'^facility/(?P<name>[a-z]+)/$', views.facility, name='facility'),
    url(r'^feedback/(?P<name>[a-z]+)/$', views.feedback, name='feedback'),
    url(r'^medical/(?P<name>[a-z]+)/$', views.medical, name='medical'),
    url(r'^policy/(?P<name>[a-z]+)/$', views.policy, name='policy'),
    url(r'^tourism/(?P<name>[a-z]+)/$', views.tourism, name='tourism'),
    url(r'^login/$', views.user_login, name='login'),
    url(r'^logout/$', views.user_logout, name='logout'),
    url(r'^reserv/$', views.reserve, name='reserve'),
    url(r'^respage/(?P<name>[a-z]+)/$', views.respage, name='respage'),
    url(r'^profile/(?P<user>[a-z]+)/$', views.profile, name='profile'),
    url(r'^about/(?P<name>[a-z]+)/$', views.about, name='about'),
    url(r'^gallery/(?P<name>[a-z]+)/$', views.gallery, name='gallery'),
]
