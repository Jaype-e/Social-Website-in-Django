from django.shortcuts import render, render_to_response
# Create your views here.
from django.template import loader, RequestContext
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect, HttpResponse
from .models import Question
from .models import News,Post
from django.shortcuts import get_object_or_404, render, redirect
from .forms import UserForm
from django.contrib.auth import authenticate, login, logout
from django.views.generic import View
from django.contrib.auth.decorators import login_required
from forms import Res
from .models import Reserv
from django.core.mail import send_mail, BadHeaderError

def home(request, page=0):
    a=int(page)
    a=a+3
    list = News.objects.order_by('-pub_date')[page:a]
    img=Post.objects.order_by('-date')[0:8]
    return render(request, 'polls/home1.html', {'list': list,'page':a,'img':img})


@login_required
def profile(request, user):
    pro = Reserv.objects.filter(user=user)
    return render(request, 'polls/profile.html', {'pro': pro})


def detail(request, question_id):
    return HttpResponse("You're looking at question %s." % question_id)


def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)


def vote(request, question_id):
    return HttpResponse("You're voting on question %s." % question_id)


def reservation(request):
    template = loader.get_template('polls/Reservation.html')
    return HttpResponse(template.render(request))


def contact(request,name):
    return render(request, 'polls/contactus.html', {'name': name})

def gallery(request,name):
    img=Post.objects.all()
    return render(request, 'polls/gallery.html', {'name': name,'img':img})

def facility(request,name):
    return render(request, 'polls/facilities.html', {'name': name})


@login_required
def feedback(request,name):
    return render(request, 'polls/feedback.html', {'name': name})


def medical(request,name):
    return render(request, 'polls/medical.html', {'name': name})


def policy(request,name):
    return render(request, 'polls/policy.html', {'name': name})


def tourism(request,name):
    return render(request, 'polls/tourism.html', {'name': name})

def about(request,name):
    return render(request, 'polls/about.html', {'name': name})


def register(request):
    context = RequestContext(request)
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)

        if user_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()

            registered = True
        else:
            print user_form.errors
    else:
        user_form = UserForm()

    return render(request, "polls/register.html", {'user_form': user_form, 'registered': registered}, context)


def user_login(request):
    next = request.GET.get('next', '/polls')
    context = RequestContext(request)
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect(next)
            else:
                return HttpResponse("Your account has been disabled")
        else:
            return HttpResponse("Invalid login details")
    else:
        return render(request, 'polls/login.html', {'redirect_to': next}, context)


@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/polls')


@login_required
def reserve(request):
    if request.method == 'GET':
        Info = Res(request.GET)
        if Info.is_valid():
            user1 = Info.cleaned_data['user']
            start_date1 = Info.cleaned_data['start_date']
            end_date1 = Info.cleaned_data['end_date']
            room1 = Info.cleaned_data['room']
            context = {'user': user1, 'start_date': start_date1, 'end_date': end_date1, 'room': room1}
            date1 = []
            Err = {'Dat1': False, 'Dat2': False, 'Dat3': False}
            Err.update(context)
            try:
                date1 = map(int, start_date1.split('/'))
            except:
                Err['Dat1'] = True
                return render(request, 'polls/reserv.html', Err)
            if len(date1) != 3:
                Err['Dat1'] = True
                return render(request, 'polls/reserv.html', Err)

            date2 = []
            try:
                date2 = map(int, end_date1.split('/'))
            except:
                Err['Dat2'] = True
                return render(request, 'polls/reserv.html', Err)
            if len(date2) != 3:
                Err['Dat2'] = True
                return render(request, 'polls/reserv.html', Err)
            dat = 0
            try:
                dat = int(room1)
            except:
                Err['Dat3'] = True
                return render(request, 'polls/reserv.html', Err)
            if dat > 4:
                Err['Dat3'] = True
                return render(request, 'polls/reserv.html', Err)
            sender=request.user.email
            Rese = Reserv(user=user1, start_date=start_date1, end_date=end_date1, room=room1)
            Rese.save()
            subject = request.POST.get('subject', '')
            message = "thank you!"+user1+" for booking room in iit bhu guest house \n from date"+start_date1+" to "+end_date1+"\n As soon as possible we notify you for confirmation "
            from_email = 'guptajape@gmail.com'
            try:
                message = message + str('\n') + str(from_email)
                send_mail(subject, message, from_email, [sender])
            except BadHeaderError:
                return HttpResponse('Invalid header found.')
            return render(request, 'polls/resSucc.html', context)

        else:
            log = "Invalid"
    return render(request, 'polls/reserv.html')


@login_required
def respage(request,name):
    return render(request, 'polls/reserv.html', {'name': name})




