from django.contrib.auth.models import User
from django import forms
from .models import Reserv


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']


class Res(forms.Form):
    user = forms.CharField(max_length=30)
    start_date = forms.CharField(max_length=20)
    end_date = forms.CharField(max_length=20)
    room = forms.CharField(max_length=20)

    class Meta:
        model = Reserv
        field = ['user', 'start_date', 'end_date', 'room']